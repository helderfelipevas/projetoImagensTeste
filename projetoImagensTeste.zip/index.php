<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Sistema Imagens</title>
    </head>
    <body>
    <center>
        <h1>Sistema Imagens</h1>
        <input type="button" id="btnCadastrar" name="btnCadastrar" value="Cadastrar Imagem" onclick="javascript: location.href='view/cadastrarImagem.php';" />
        <input type="button" id="btnListar" name="btnListar" value="Listar Imagem" onclick="javascript: location.href='view/listarImagem.php';"/>
    </center>
    </body>
</html>
